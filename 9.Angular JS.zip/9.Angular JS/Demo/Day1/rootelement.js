var myApp= angular.module("myApp",[]);

myApp.directive("myDirective",['$rootElement',"$log",function($rootElement,$log)
{
    return {
        restrict:"E",
        template:"<button ng-click='changeGreenBackground()'>Change BackGround {{color}}</button>",
        link: function(scope,element,attr){
          scope.changeGreenBackground= function(){
            $log.log($rootElement);
            $rootElement.css("background","cyan");
          };
        }
    };
}]);



//http://www.tutorialsavvy.com/2014/11/angularjs-rootelement-example.html/  
//Rootelement Example


