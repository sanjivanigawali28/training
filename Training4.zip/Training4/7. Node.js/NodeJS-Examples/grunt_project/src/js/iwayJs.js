function printMsg (getMsg) {	console.log(getMsg);
}

var iway = function (msg) {
	return printMsg(msg);}

iway("iway iway!!");