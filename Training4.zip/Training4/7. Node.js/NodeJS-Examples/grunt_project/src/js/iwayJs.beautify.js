function printMsg(a) {
    console.log(a);
}

var iway = function(a) {
    return printMsg(a);
};

iway("iway iway!!");