var names = require('./name');
console.log("My name is " + names.myName);