module.exports = {
	rajan : function() {
		console.log("Hi, I am Rajan");
	},

	kumar : function() {
		console.log("Hi, I am Kumar");
	}
};