var mod = require('./one');

//console.log(mod);

console.log(mod.one);
console.log(mod.two);