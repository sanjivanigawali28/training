/*
**Sync Code


var numbers = [1,2,3,4,5,6,7,8,9];
function odds(arr) {
	return 	arr.filter(function(n){
		return n % 2;
	});
}

var oddNums = odds(numbers);
console.log(oddNums);
*/

/*
**Async Code
*/

function odds(arr, callback) {
	var oddNums = arr.filter(function(n) {
		return n % 2;	
	});
	
	var err = arr.indexOf(3) > -1 ? "No 3s allowed" : null;
	
	setTimeout(function(){
		callback(err, oddNums);
	}, 0);
}

var numbers = [1,2,4,5,6,7,8,9];

odds(numbers, function(err, data){
	if (err) throw err;
	console.log("data: ", data);
});

console.log("comes after odds function");