var one = 1;
var two = 2;
console.log(module.exports);

module.exports.one = one;
module.exports.two = two;

console.log(module.exports);