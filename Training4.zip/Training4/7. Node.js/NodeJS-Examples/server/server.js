var http  = require('http');

function myServer(req, res){
	console.log("we have request, lets process this");
	res.writeHead(200, {"Content-Type" : "text/plain"});
	res.write("Hello World, Enddasdasdas");
	res.end();
}

http.createServer(myServer).listen(8080);

console.log('server is started');