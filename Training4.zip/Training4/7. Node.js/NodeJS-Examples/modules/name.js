function printRajan (){
	console.log("Hi, I am Rajan");
}

function printKumar (){
	console.log("Hi, I am Kumar");
}

module.exports.rajan = printRajan;
module.exports.kumar = printKumar;