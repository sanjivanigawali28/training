var names = require('./name.js');

console.log(names.rajan());
console.log(names.kumar());