module.exports = function (){
	return {
		frndName : ""
	}
};

//console.log(module.exports());