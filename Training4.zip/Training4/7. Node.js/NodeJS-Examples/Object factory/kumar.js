var names = require('./name');
var printFriend = names();
printFriend.frndName = "gopal";
console.log('Kumar is friend of ' + printFriend.frndName);