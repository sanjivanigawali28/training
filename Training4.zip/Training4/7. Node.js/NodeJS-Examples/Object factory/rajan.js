var names = require('./name');
var printFriend = names();
printFriend.frndName = "ram";
console.log('Rajan is friend of ' + printFriend.frndName);