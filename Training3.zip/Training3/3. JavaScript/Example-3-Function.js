//function declaration
function square(a){
 return a * a;
}

//calling function
var result = square(4);
console.log(result);//16

//OR
square(4);//16