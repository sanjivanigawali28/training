console.log("Hello JavaScript");//write in the console
		