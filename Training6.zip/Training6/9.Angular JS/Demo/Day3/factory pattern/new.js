var contactApp = angular.module("contactApp",[]);


contactApp.factory("contactFactory",function()
{
   var obj = {};
   contactList = [];
   uid = 0;    
       obj.createContact = function(newContact)
        {
             var contact = {
        
            };
            if(newContact.id == null)
            {
                console.log("creating new contact");
                contact = newContact;
                contact.id = ++uid;
                contactList.push(contact);
            }
            else
            {
                console.log("editing");
                for(i in contactList)
                {
                    if(contactList[i].id == newContact.id)
                    {
                        contactList[i] = newContact;
                    }
                }
            }
           
        };
        obj.getList = function()
        {
            return contactList;
        };
        obj.getContact = function(id)
        {
          for (i in contactList)
          {
              if(contactList[i].id == id)
              {
                  return contactList[i];
              }
          }
        };
        obj.deleteContact = function(id) 
        {
        for (i in contactList) {
            if (contactList[i].id == id) 
            {
                contactList.splice(i, 1);
            }
        }
        };
    return obj;    
        
       
});



contactApp.controller("contactController",function($scope,contactFactory){
    
     
     
   var t = contactFactory; 
    $scope.getObject = function()
    {
        t.createContact($scope.newContact);
        $scope.contactList = t.getList();
        $scope.newContact = {};
        
    };
    
    $scope.editContact = function(id)
    {
       
       $scope.newContact = angular.copy(t.getContact(id));
       
    };
    $scope.deleteContact = function(id)
    {
        t.deleteContact(id);
    }
   
});

