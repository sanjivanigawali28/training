var myApp = angular.module('scopeInheritance', []);

myApp.controller('MainController', ['$scope', '$rootScope', function($scope, $rootScope) {
	$scope.timeOfDay = 'morning';
	$scope.name = 'Nikki';
	$rootScope.data = 'Check this out';
}]);

myApp.controller('ChildController', ['$scope', function($scope) {
	$scope.timeOfDay = 'afternoon';
	$scope.name = 'Mattie';
}]);

myApp.controller('GrandChildController', ['$scope', function($scope) {
	$scope.timeOfDay = 'evening';
	console.log($scope.$parent.name);
	//$scope.name = 'Gingerbread Baby';
}]);

/************************************************
*	Questions
*		1. Remember the prototype pattern?
*
*		2. What will happen if $scope.name 
*		assignment was commented out in 
*		GrandChildController?
*
*		3. Can I access ChildController scope 
*		from GrandChildController?
*
*		4. What is $rootScope, how to pass it in 
*		and where is it accessible?
**************************************************/