var App = angular.module('App', []);

App.directive('btn', function($timeout) {
	return {
		restrict: 'A',
		priority: 0,
		link: function(scope, element, attrs) {
			element.addClass('btn');
		}
	};
});

App.directive('primary', function($http) {
	return {
		restrict: 'A',
		priority: 1,
		link: function(scope, element, attrs) {
			if (element.hasClass('btn')) {
				element.addClass('btn-primary');
			}
		}
	};
});