var app = angular.module('myApp', []);
app.controller('validateCtrl', function($scope) {
    $scope.user = 'Samuel Joe';
    $scope.email = 'samuel.joe@gmail.com';
});