	$(document).ready(function(){
		
		var input = $('div#disp');
		var equals = $('[name="equals"]');
		var firstInput;
		
	$('.btn').click(function(){
		
		var old=$('#disp').html();
		var current=$(this).val();
		var con=old+current;
		$('#disp').html(con);	
		
	});
	
	$('.operation').on('click', function() {
		
		var opName = $(this).attr('name');
		//console.log(opName);
		firstInput = parseFloat($('#disp').html());
		console.log(firstInput);

        input.attr('name', $('div#disp').html());
        $('div#disp').html('');
        equals.removeClass();
        equals.addClass(opName);
   
	});

	equals.on('click', function() {
		
		var secondInput = parseFloat($('#disp').html());
			console.log(secondInput);
		if (equals.hasClass('add')) {
			
			var output=(firstInput + secondInput);
			 $('#disp').html(output);
			 
		} 
		else if (equals.hasClass('subtract')) {
		
			var output=(firstInput - secondInput);
			 $('#disp').html(output);
			 
		} 
		else if (equals.hasClass('multiply')) {
			
			var output=(firstInput * secondInput);
			 $('#disp').html(output);
			 
		} 
		else if (equals.hasClass('divide')) {
			
			var output=(firstInput / secondInput);
			 $('#disp').html(output);
			 
		}
		else if (equals.hasClass('scientificRoot')) {
			
			var output= Math.sqrt(firstInput);
			 $('#disp').html(output);
			 
		}
		else if (equals.hasClass('scientificSquare')) {
			
			var output= (firstInput * firstInput);
			 $('#disp').html(output);
			 
		}
		else if (equals.hasClass('scientificCube')) {
			
			var output= (firstInput * firstInput * firstInput);
			 $('#disp').html(output);
			 
		}
		
	});
	
	/* $('.doubleClick').bind('click',function(e){
    e.preventDefault();
	}); */
	
	$('.clr').on('click', function () {
		$('#disp').html("");
	});

});