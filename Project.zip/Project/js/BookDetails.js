
	$(document).ready(function(){

		$("#showData").click(function(){
			$("span").show();
		});
		
	});

